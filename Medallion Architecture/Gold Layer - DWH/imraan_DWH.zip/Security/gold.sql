CREATE SCHEMA [gold]
    AUTHORIZATION [dbo];


GO
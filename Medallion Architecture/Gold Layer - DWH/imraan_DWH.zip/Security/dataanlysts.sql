CREATE ROLE [dataanlysts]
    AUTHORIZATION [dbo];


GO
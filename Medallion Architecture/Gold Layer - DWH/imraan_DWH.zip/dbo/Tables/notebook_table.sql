CREATE TABLE [dbo].[notebook_table] (
    [id]     INT           NULL,
    [name]   VARCHAR (100) NULL,
    [salary] VARCHAR (100) NULL
);


GO
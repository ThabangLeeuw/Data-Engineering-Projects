CREATE TABLE [dbo].[dummy_table] (
    [Branch_ID]      VARCHAR (255) NULL,
    [Dealer_ID]      VARCHAR (255) NULL,
    [Model_ID]       VARCHAR (255) NULL,
    [Revenue]        BIGINT        NULL,
    [Units_Sold]     BIGINT        NULL,
    [Date_ID]        VARCHAR (255) NULL,
    [Day]            INT           NULL,
    [Month]          INT           NULL,
    [Year]           INT           NULL,
    [BranchName]     VARCHAR (255) NULL,
    [DealerName]     VARCHAR (255) NULL,
    [Model_Category] VARCHAR (255) NULL,
    [RevPerUnit]     FLOAT (53)    NULL
);


GO
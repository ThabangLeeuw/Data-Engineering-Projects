CREATE TABLE [dbo].[demo_table] (
    [id]   INT           NULL,
    [name] VARCHAR (200) NULL
);


GO
CREATE TABLE [dbo].[test_table] (
    [id]   INT           NULL,
    [name] VARCHAR (100) NULL
);


GO
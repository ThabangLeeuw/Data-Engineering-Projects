CREATE FUNCTION customers_function (@customer_zip INT)
RETURNS TABLE
AS
RETURN
(
    SELECT * FROM imraan_DWH.gold.cur_customers
    WHERE
        customer_zip_code = @customer_zip
)

GO
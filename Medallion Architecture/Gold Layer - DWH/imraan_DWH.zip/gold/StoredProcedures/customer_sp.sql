CREATE PROCEDURE gold.customer_sp(@customer_zip INT)
AS
BEGIN
    SELECT * FROM imraan_DWH.gold.cur_customers
    WHERE customer_zip_code = @customer_zip
END;

GO
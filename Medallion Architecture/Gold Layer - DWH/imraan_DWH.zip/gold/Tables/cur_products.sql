CREATE TABLE [gold].[cur_products] (
    [product_id]                 VARCHAR (8000) NULL,
    [product_category_name]      VARCHAR (8000) NULL,
    [product_name_lenght]        VARCHAR (8000) NULL,
    [product_description_lenght] VARCHAR (8000) NULL,
    [product_photos_qty]         VARCHAR (8000) NULL,
    [product_weight_g]           INT            NULL,
    [product_length_cm]          INT            NULL,
    [product_height_cm]          INT            NULL,
    [product_width_cm]           INT            NULL,
    [300gFlag]                   VARCHAR (8000) NULL
);


GO
CREATE TABLE [gold].[cur_reviews] (
    [review_id]               VARCHAR (8000) NULL,
    [order_id]                VARCHAR (8000) NULL,
    [review_score]            VARCHAR (8000) NULL,
    [review_comment_title]    VARCHAR (8000) NULL,
    [review_comment_message]  VARCHAR (8000) NULL,
    [review_creation_date]    VARCHAR (8000) NULL,
    [review_answer_timestamp] VARCHAR (8000) NULL
);


GO
CREATE TABLE [gold].[cur_orders] (
    [order_id]                      VARCHAR (8000) NULL,
    [customer_id]                   VARCHAR (8000) NULL,
    [order_status]                  VARCHAR (8000) NULL,
    [order_purchase_timestamp]      DATETIME2 (6)  NULL,
    [order_approved_at]             VARCHAR (8000) NULL,
    [order_delivered_carrier_date]  VARCHAR (8000) NULL,
    [order_delivered_customer_date] VARCHAR (8000) NULL,
    [order_estimated_delivery_date] VARCHAR (8000) NULL
);


GO
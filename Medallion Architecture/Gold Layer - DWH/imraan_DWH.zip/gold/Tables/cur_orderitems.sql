CREATE TABLE [gold].[cur_orderitems] (
    [order_id]            VARCHAR (8000) NULL,
    [order_item_id]       INT            NULL,
    [product_id]          VARCHAR (8000) NULL,
    [seller_id]           VARCHAR (8000) NULL,
    [shipping_limit_date] DATETIME2 (6)  NULL,
    [price]               REAL           NULL,
    [freight_value]       REAL           NULL
);


GO
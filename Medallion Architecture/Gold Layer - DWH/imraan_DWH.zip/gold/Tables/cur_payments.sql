CREATE TABLE [gold].[cur_payments] (
    [order_id]             VARCHAR (8000) NULL,
    [payment_sequential]   VARCHAR (8000) NULL,
    [payment_type]         VARCHAR (8000) NULL,
    [payment_installments] INT            NULL,
    [payment_value]        INT            NULL
);


GO
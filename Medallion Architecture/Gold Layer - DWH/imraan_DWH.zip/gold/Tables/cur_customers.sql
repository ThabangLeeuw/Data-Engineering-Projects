CREATE TABLE [gold].[cur_customers] (
    [customer_id]       VARCHAR (8000) MASKED WITH (FUNCTION = 'partial(0, "***-**-", 4)') NULL,
    [unique_id]         VARCHAR (8000)                                                     NULL,
    [customer_zip_code] INT                                                                NULL
);


GO
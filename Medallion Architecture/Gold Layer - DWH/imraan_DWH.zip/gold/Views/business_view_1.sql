CREATE VIEW [gold].business_view_1 
AS
WITH CTE1 AS 
(
SELECT T1.*, T2.weight_flag
FROM
(SELECT o.order_id, oi.product_id
from imraan_DWH.gold.cur_orders o
LEFT JOIN
    imraan_DWH.gold.cur_orderitems oi
    ON
        o.order_id = oi.order_id
where order_status = 'delivered'
) T1
LEFT JOIN
(SELECT product_id, product_weight_g,
    CASE
    WHEN product_weight_g <= 1000 then 'Low'
    WHEN product_weight_g <= 5000 then 'Mid'
    ELSE 'High' 
    END AS weight_flag
FROM imraan_DWH.gold.cur_products  
) T2
ON T1.product_id = T2.product_id
)

SELECT weight_flag, COUNT(order_id) as total_orders
FROM CTE1
GROUP BY weight_flag

GO
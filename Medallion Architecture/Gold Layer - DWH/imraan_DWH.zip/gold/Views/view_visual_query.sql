CREATE VIEW [gold].[view_visual_query] AS select [$Table].[customer_id] as [customer_id],
    [$Table].[unique_id] as [unique_id],
    [$Table].[customer_zip_code] as [customer_zip_code]
from [imraan_DWH].[gold].[cur_customers] as [$Table]

GO
CREATE VIEW gold.business_view_2
AS
SELECT * FROM
(
SELECT
    *,
    DENSE_RANK() OVER (PARTITION BY payment_type ORDER BY payment_value) as bucket_ranking
FROM
    imraan_DWH.gold.cur_payments
) as T
WHERE bucket_ranking <=10

GO